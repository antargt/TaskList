/* 
 *  
 * Simple main method which points to main menu in the Validator class
 * 
 * Future Mods:
 * 		1) add functionality for more than one list of tasks.
 * 		2) Save to a file.
 *  
 */

package com.anthonyaragon.finalproject;

public class FinalProject extends Validator{

	public static void main(String[] args) {

		mainMenu();  // displays main menu by running Main Menu method in Validator Class 
	}
}
